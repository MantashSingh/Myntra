import React, { Component } from "react"
import { View, Text, Image, StyleSheet } from "react-native"
import BtnComponent from "../../Component/BtnCompoment"
import imagePath from "../../Images/imagePath"


export default class LatestDeals extends Component {
    render() {
        return (

            <View>
                <View style={styles.rowDirection}>
                    <Text style={styles.footware} >FOOTWEAR</Text>

                    <Image style={styles.icon}
                        source={imagePath.search}
                    />
                    <Image style={styles.icon}
                        source={imagePath.heart}
                    />
                    <Image style={styles.icon}
                        source={imagePath.cart}
                    />
                </View>


                <Text style={styles.items}>xxxx Items</Text>


                <Image style={styles.footwareImg}
                    source={imagePath.footware}
                />


                <View>
                    <View>
                        <Image style={styles.shoes}
                            source={imagePath.shoe1}
                        />

                        {/* <Image style={styles.shoes}
                        source={imagePath.shoe2}
                    /> */}

                    </View>
                    <Text style={{ fontWeight: "bold", marginLeft: 5 }}>Reebok</Text>
                    <Text style={{ color: "gray", marginLeft: 5 }}>Men Travellar LP Running</Text>
                    <View style={styles.rowDirection}>
                        <Text  >Rs 1,999</Text>
                        <Text style={{ textDecorationLine: 'line-through', textDecorationStyle: 'solid', fontSize: 12, marginTop: 2, marginRight: 3 }}> Rs 2,555</Text>
                        <Text style={{ color: "red" }}>38% OFF</Text>

                    </View>


                    


                </View>

            </View>

        )
    }
}

const styles = StyleSheet.create({
    rowDirection: {
        flexDirection: "row",
        marginTop:10

    },
    icon: {
        width: 30,
        height: 30,
        marginRight: 10,
    },
    footware: {
        fontSize: 20,
        fontWeight: "bold",
        marginLeft: 30,
        marginRight: 100

    },
    items: {
        marginTop: -10,
        marginLeft: 45,
        color: "gray"

    },
    footwareImg: {
        width: 350,
        height: 50,
        marginTop: 20,
        marginLeft: 5
    },
    shoes: {
        width: 170,
        height: 200,
        marginRight: 8,
        marginLeft: 5
    }

})