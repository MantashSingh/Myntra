export default {
    TAB_ROUTES:'tabRoutes',
    LOGIN:'login',
    SIGNUP:'signup',
    // HOME:'homePage',
    SUPERCOINS:'superCoins',
    VIDEO:'video',
    GAME_ZONE:'gameZone',
    LANDING_PAGE:'landingPage',
    LOGIN:'login',
    SIGNUP:'signup',
    // HOME:'homePage',
    MAIN_PAGE:'homePage'
    

}